import { onRequest as __api_admin_login_ts_onRequest } from "E:\\AI\\Trae\\个人网站\\个人网站-·-设计与工程作品集 (1)\\functions\\api\\admin\\login.ts"
import { onRequest as __api_admin_logout_ts_onRequest } from "E:\\AI\\Trae\\个人网站\\个人网站-·-设计与工程作品集 (1)\\functions\\api\\admin\\logout.ts"
import { onRequest as __api_messages_ts_onRequest } from "E:\\AI\\Trae\\个人网站\\个人网站-·-设计与工程作品集 (1)\\functions\\api\\messages.ts"

export const routes = [
    {
      routePath: "/api/admin/login",
      mountPath: "/api/admin",
      method: "",
      middlewares: [],
      modules: [__api_admin_login_ts_onRequest],
    },
  {
      routePath: "/api/admin/logout",
      mountPath: "/api/admin",
      method: "",
      middlewares: [],
      modules: [__api_admin_logout_ts_onRequest],
    },
  {
      routePath: "/api/messages",
      mountPath: "/api",
      method: "",
      middlewares: [],
      modules: [__api_messages_ts_onRequest],
    },
  ]